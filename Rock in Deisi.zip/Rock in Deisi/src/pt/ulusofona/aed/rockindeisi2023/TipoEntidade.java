package pt.ulusofona.aed.rockindeisi2023;

public enum TipoEntidade {
    TEMA, ARTISTA, INPUT_INVALIDO;
}
