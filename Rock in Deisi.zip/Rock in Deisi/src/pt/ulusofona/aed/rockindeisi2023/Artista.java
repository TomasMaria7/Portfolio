package pt.ulusofona.aed.rockindeisi2023;

import java.util.List;

public class Artista {
    String nome;
    int musicas;

    public Artista(String nome, int musicas) {
        this.nome = nome;
        this.musicas = musicas;
    }



    @Override
    public String toString() {
        if(nome.charAt(0) == 'A' ||nome.charAt(0) == 'B' ||nome.charAt(0) == 'C' ||nome.charAt(0) == 'D' ){
            return "Artista: [" + nome + "]";
        }else{
            return  "Artista: [" + nome + "] | " + musicas;
        }
    }
}
