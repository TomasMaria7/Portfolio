package pt.ulusofona.aed.rockindeisi2023;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TesteArtista {

    @Test
    public void artistasSimples() {

        Artista resultadoAtual = new Artista("André", 2);
        String resultadoEsperado = "Artista: [" + resultadoAtual.nome + "]";

        Assertions.assertEquals(resultadoEsperado, resultadoAtual.toString(), "Teste Arstista com erro");

    }


    @Test
    public void artistasSomplexos() {

        Artista resultadoAtual = new Artista("João", 2);
        String resultadoEsperado = "Artista: [" + resultadoAtual.nome + "] | " + resultadoAtual.musicas;

        Assertions.assertEquals(resultadoEsperado, resultadoAtual.toString(), "Teste Arstista com erro");
    }

}
