package pt.ulusofona.aed.rockindeisi2023;

import java.util.ArrayList;

public class Musicas {
    String id;

    String titulo;

    int ano;
    ArrayList<String> artistas;
    int duracao;
    int explicito;
    int popularidade;
    double dancabilidade;
    double vivacidade;
    double volumeMedio;

    public Musicas(String  id, String titulo, int ano,  ArrayList<String> artistas, int duracao, int explicito, int popularidade, double dancabilidade, double vivacidade, double volumeMedio){
        this.id = id;
        this.titulo = titulo;
        this.ano = ano;
        this.artistas = artistas;
        this.duracao = duracao;
        this.explicito = explicito;
        this.popularidade = popularidade;
        this.dancabilidade = dancabilidade;
        this.vivacidade = vivacidade;
        this.volumeMedio = volumeMedio;


    }
    public Musicas(String id, String titulo, int ano){
        this.id = id;
        this.titulo = titulo;
        this.ano = ano;
    }

    public Musicas(String id,  ArrayList<String> artistas){
        this.id = id;
        this.artistas = artistas;
    }

}