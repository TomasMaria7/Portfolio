package pt.ulusofona.aed.rockindeisi2023;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.File;

public class TesteInputInvalido {

    @Test
    public void ComErro() {
        boolean resultadoEsperado = false;
        File songs = new File("test-files");
        boolean resultadoAtual = Main.loadFiles(songs);

        if (resultadoAtual != resultadoEsperado) {
            System.out.println("ComErro Está certo!");
        } else {
            Assertions.fail("Teste InputInvalido errado");
        }
    }

    @Test
    public void SemErro() {
        boolean resultadoEsperado = true;
        File songs = new File("test-files");
        boolean resultadoAtual = Main.loadFiles(songs);

        if (resultadoAtual == resultadoEsperado) {
            System.out.println("SemErro Está certo!");
        } else {
            Assertions.fail("Teste InputInvalido errado");
        }
    }

}
