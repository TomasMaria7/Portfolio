package pt.ulusofona.aed.rockindeisi2023;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TesteTema {

    @Test
    public void antes1995(){

        Tema resultadoAtual = new Tema("17ZnveSDBpG9QtL7zLJNPy", "Only For You", 1945, "3:45", 3, 1);
        String resultadoEsperado = resultadoAtual.id + " | " + resultadoAtual.titulo + " | " + resultadoAtual.ano;

        Assertions.assertEquals(resultadoEsperado, resultadoAtual.toString(), "Teste Tema com erro");

    }

    @Test
    public void antes2000(){

        Tema resultadoAtual = new Tema("17ZnveSDBpG9QtL7zLJNPy", "Only For You", 1996, "3:45", 3, 1);
        String resultadoEsperado = resultadoAtual.id + " | " + resultadoAtual.titulo + " | " + resultadoAtual.ano + " | " + resultadoAtual.duracao  + " | " + resultadoAtual.popularidade;

        Assertions.assertEquals(resultadoEsperado, resultadoAtual.toString(), "Teste Tema com erro");

    }

    @Test
    public void depois2000(){

        Tema resultadoAtual = new Tema("17ZnveSDBpG9QtL7zLJNPy", "Only For You", 2003, "3:45", 3, 1);
        String resultadoEsperado = resultadoAtual.id + " | " + resultadoAtual.titulo + " | " + resultadoAtual.ano + " | " + resultadoAtual.duracao  + " | " + resultadoAtual.popularidade + " | " + resultadoAtual.numArtistas;

        Assertions.assertEquals(resultadoEsperado, resultadoAtual.toString(), "Teste Tema com erro");

    }


}
