package pt.ulusofona.aed.rockindeisi2023;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class Main {
    static ArrayList<Musicas> musicas = new ArrayList<>();

    static ArrayList<InputInvalido> inputInvalidos = new ArrayList<>();

    static ArrayList<Artista> artistas = new ArrayList<>();

    public static boolean loadFiles(File folder) {
        inputInvalidos = new ArrayList<>();
        musicas = new ArrayList<>();
        artistas = new ArrayList<>();

        File ficheiroMusicas = new File(folder, "songs.txt");
        Scanner scanner = null;
        try {
            scanner = new Scanner(ficheiroMusicas);
        } catch (FileNotFoundException e) {

            return false;
        }
        InputInvalido input_invalidoSong = new InputInvalido("songs.txt", 0, 0, -1);
        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            String[] partes = linha.split("@");
            if (partes.length == 3) {

                boolean verificaDuplicado = false;

                for (Musicas musica : musicas) {
                    if (musica.id.equals(partes[0].trim())) {
                        verificaDuplicado = true;
                        break;
                    }
                }

                if (verificaDuplicado == false) {
                    Musicas musica = new Musicas(partes[0].trim(), partes[1].trim(), Integer.parseInt(partes[2].trim()));
                    musicas.add(musica);
                    input_invalidoSong.linhasOK++;
                } else {
                    if (input_invalidoSong.primeiraLinhaNOK == -1) {
                        input_invalidoSong.primeiraLinhaNOK = input_invalidoSong.linhasOK + 1;
                    }
                    input_invalidoSong.linhasNOK++;
                }

            } else {
                if (input_invalidoSong.primeiraLinhaNOK == -1) {
                    input_invalidoSong.primeiraLinhaNOK = input_invalidoSong.linhasOK + 1;
                }
                input_invalidoSong.linhasNOK++;
            }
        }
        inputInvalidos.add(input_invalidoSong);

        File ficheiroDetalhes = new File(folder, "song_details.txt");
        try {
            scanner = new Scanner(ficheiroDetalhes);
        } catch (FileNotFoundException e) {
            return false;
        }
        InputInvalido input_invalidoDetalhes = new InputInvalido("song_details.txt", 0, 0, -1);
        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            String[] partes = linha.split("@");
            if (partes.length == 7) {
                for (Musicas musica : musicas) {
                    if (musica.id.equals(partes[0].trim())) {
                        musica.duracao = Integer.parseInt(partes[1].trim());
                        musica.explicito = Integer.parseInt(partes[2].trim());
                        musica.popularidade = Integer.parseInt(partes[3].trim());
                        musica.dancabilidade = Double.parseDouble(partes[4].trim());
                        musica.vivacidade = Double.parseDouble(partes[5].trim());
                        musica.volumeMedio = Double.parseDouble(partes[6].trim());
                    }
                }
                input_invalidoDetalhes.linhasOK++;
            } else {
                if (input_invalidoDetalhes.primeiraLinhaNOK == -1) {
                    input_invalidoDetalhes.primeiraLinhaNOK = input_invalidoDetalhes.linhasOK + 1;
                }
                input_invalidoDetalhes.linhasNOK++;
            }
        }
        inputInvalidos.add(input_invalidoDetalhes);

        File ficheiroArtistas = new File(folder, "song_artists.txt");
        try {
            scanner = new Scanner(ficheiroArtistas);
        } catch (FileNotFoundException e) {
            return false;
        }
        InputInvalido input_invalidoArtistas = new InputInvalido("song_artists.txt", 0, 0, -1);
        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            String[] partes = linha.split("@");

            if (partes.length == 2) {

                boolean verificaId = false;

                for (Musicas musica : musicas) {
                    if (musica.id.equals(partes[0].trim()) && musica.duracao > 0) {
                        verificaId = true;
                        break;
                    }
                }

                if (verificaId) {
                    partes[1] = partes[1].trim();
                    String[] partesAux = null;

                    switch (partes[1].charAt(0)) {
                        case '"' -> {
                            partes[1] = partes[1].substring(1, partes[1].length() - 1).trim();
                            partes[1] = partes[1].substring(1, partes[1].length() - 1).trim();
                            partesAux = partes[1].split(",");

                            for (int i = 0; i < partesAux.length; i++) {
                                partesAux[i] = partesAux[i].trim();
                                partesAux[i] = partesAux[i].substring(1, partesAux[i].length() - 1).trim();
                            }

                            for (Musicas musica : musicas) {
                                if (musica.id.equals(partes[0].trim())) {
                                    if (musica.artistas != null) {
                                        musica.artistas.addAll(Arrays.asList(partesAux));
                                    } else {
                                        musica.artistas = new ArrayList<>(Arrays.asList(partesAux));
                                    }
                                }
                            }
                        }
                        case '[' -> {

                            partes[1] = partes[1].substring(1, partes[1].length() - 1).trim();
                            partes[1] = partes[1].substring(1, partes[1].length() - 1).trim();
                            partesAux = partes[1].split(",");

                            if (partesAux.length == 1) {
                                for (Musicas musica : musicas) {
                                    if (musica.id.equals(partes[0].trim())) {
                                        if (musica.artistas != null) {
                                            musica.artistas.addAll(Arrays.asList(partesAux));
                                        } else {
                                            musica.artistas = new ArrayList<>(Arrays.asList(partesAux));
                                        }
                                    }
                                }
                            }else{
                                partesAux = null;
                            }

                        }
                    }

                    if (partesAux != null) {
                        for (String aux : partesAux) {
                            boolean existeArtista = false;
                            for (Artista artista : artistas) {
                                if (aux.trim().equals(artista.nome)) {
                                    artista.musicas++;
                                    existeArtista = true;
                                }
                            }

                            if (existeArtista == false) {
                                Artista artista = new Artista(aux.trim(), 1);
                                artistas.add(artista);
                            }
                        }
                    }

                }

                input_invalidoArtistas.linhasOK++;

            } else {
                if (input_invalidoArtistas.primeiraLinhaNOK == -1) {
                    input_invalidoArtistas.primeiraLinhaNOK = input_invalidoArtistas.linhasOK + 1;
                }
                input_invalidoArtistas.linhasNOK++;
            }
        }
        inputInvalidos.add(input_invalidoArtistas);
        return true;
    }

    public static ArrayList getObjects(TipoEntidade tipo) {


        if (tipo == TipoEntidade.ARTISTA) {
            return artistas;
        }
        if (tipo == TipoEntidade.TEMA) {
            ArrayList<Tema> temas = new ArrayList<>();
            for (Musicas musica : musicas) {
                if (musica.artistas != null && musica.artistas.size() > 0 && musica.duracao > 0) {
                    Tema tema = new Tema(musica.id, musica.titulo, musica.ano, "", musica.popularidade, musica.artistas.size());

                    int minutos = (int) (musica.duracao / 60000);
                    int segundos = (int) (musica.duracao / 1000) - (minutos * 60);

                    if (segundos < 10) {
                        tema.duracao = minutos + ":0" + segundos;
                    } else {
                        tema.duracao = minutos + ":" + segundos;
                    }
                    temas.add(tema);
                }
            }

            return temas;

        }
        if (tipo == TipoEntidade.INPUT_INVALIDO) {


            return inputInvalidos;

        }
        return null;
    }


    public static void main(String[] args) {
        loadFiles(new File("test-files"));
        TipoEntidade ent = TipoEntidade.ARTISTA;
        ArrayList arrayList = getObjects(ent);
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.println(arrayList.get(i));
        }

        System.out.println("\n------------------------------------------------------------------------------------------\n");

        ent = TipoEntidade.TEMA;
        arrayList = getObjects(ent);
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.println(arrayList.get(i));
        }

        System.out.println("\n------------------------------------------------------------------------------------------\n");

        ent = TipoEntidade.INPUT_INVALIDO;
        arrayList = getObjects(ent);
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.println(arrayList.get(i));
        }
    }


}