Humano: Como converter um Array de Strings para ArrayList<String> em java 
--------------------------
Chatgpt: Para converter um array de Strings em um ArrayList<String> em
Java, você pode usar o método Arrays.asList() para criar uma 
lista imutável a partir do array e, em seguida, passar essa lista 
para o construtor do ArrayList.

Aqui está um exemplo de código:

// Criando um array de Strings
String[] arrayDeStrings = {"foo", "bar", "baz"};

// Convertendo o array em um ArrayList<String>
ArrayList<String> listaDeStrings = new ArrayList<String>(Arrays.asList(arrayDeStrings));

// Imprimindo o ArrayList de Strings
System.out.println(listaDeStrings);

Observe que o construtor do ArrayList que usamos aqui aceita 
uma lista como argumento, o que nos permite passar a lista 
imutável criada pelo método Arrays.asList().
--------------------------
CONCLUSÃO DO GRUPO: Ao início tentamos usar dessa maneira no programa, com Arrays.asList(partesAux), 
dentro do for nas linhas (95-116), mas o programa crashou, então obtamos por deixar só a variável partesAux, 
onde a inicializamos na linha 76 desta maneira: String[] partesAux = partes[1].split(",");
