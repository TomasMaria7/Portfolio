import java.io.File

fun auxiliarMain(querSair:String, terreno:Array<Array<String?>>,linhas:Int,colunas:Int,datainvalida:String): String {
    do {
        var coordenadas:String
        var coordenadasPair:Pair<Int,Int> = Pair(-1,-1)
        println("Qual a sua data de nascimento? (dd-mm-yyyy)")
        val data = readln()
        if (data == querSair) {
            return querSair //sai do jogo
        }
        if (validaDataNascimento(data) != null) {
            println(validaDataNascimento(data))
        }
        if (validaDataNascimento(data) != "Menor de idade nao pode jogar" && validaDataNascimento(data) != datainvalida) {
            println("\n" + criaTerreno(terreno, leContadoresDoFicheiro(linhas, colunas, true),
                    leContadoresDoFicheiro(linhas, colunas, false)))
            do {
                do {
                    println("Coordenadas da tenda? (ex: 1,B)")
                    coordenadas = readln()
                    if (coordenadas == querSair) {
                        return querSair //sai do jogo
                    }
                    if (processaCoordenadas(coordenadas, linhas, colunas) == null) {
                        println("Coordenadas invalidas")
                    }
                } while (processaCoordenadas(coordenadas, linhas, colunas) == null)
                //a função transforma as coordenadas no formato pedido
                val verificaCoordenadas = processaCoordenadas(coordenadas, linhas, colunas)
                if (verificaCoordenadas != null) {
                    coordenadasPair = verificaCoordenadas  //Dá o valor das coordenas
                }
                if (!colocaTenda(terreno, coordenadasPair)) {
                    println("Tenda nao pode ser colocada nestas coordenadas")
                } else {
                    println("\n" + criaTerreno(terreno, leContadoresDoFicheiro(linhas, colunas, true),
                            leContadoresDoFicheiro(linhas, colunas, false)))
                    //coloca a tenda nas coordenadas inseridas e mostra o terreno
                }
            } while (!terminouJogo(terreno, leContadoresDoFicheiro(linhas, colunas, true),
                            leContadoresDoFicheiro(linhas, colunas, false)))
            //só sai quando o jogo está terminado, dependendo do terreno
        }
    } while (validaDataNascimento(data) == datainvalida)
    return ""
}

fun criaMenu(): String {
    return "\nBem vindo ao jogo das tendas\n\n1 - Novo jogo\n0 - Sair\n"
}

fun validaTamanhoMapa(numLinhas: Int, numColunas: Int): Boolean {
    return when {
        //vê se os formatos do terreno inserido é válido
        numLinhas == 6 && numColunas == 5 -> true
        numLinhas == 6 && numColunas == 6 -> true
        numLinhas == 8 && numColunas == 8 -> true
        numLinhas == 10 && numColunas == 10 -> true
        numLinhas == 8 && numColunas == 10 -> true
        numLinhas == 10 && numColunas == 8 -> true
        else -> false
    }
}

fun verificaAno(data: String): String? {
    val menorIdade = "Menor de idade nao pode jogar"
    if (data[6].code in 49..50 //ano
            && data[7].code == 57 || data[7].code == 48 && data[8].code in 48..57 && data[9].code in 48..57) {
        val dia = (data[0].toString() + data[1].toString()).toInt()
        val mes = (data[3].toString() + data[4].toString()).toInt()
        val ano = (data[6].toString() + data[7].toString() + data[8].toString() + data[9].toString()).toInt()
        if (ano in 1900..2022) {
            when (mes) {
                2 -> {
                    when ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0) { //verifica se é ano bissexto ou não
                        true -> {
                            if (dia in 1..29) {
                                return if (ano <= 2004) {
                                    null
                                } else {
                                    menorIdade
                                }
                            }
                        }

                        else -> {
                            if (dia in 1..28) {
                                return if (ano <= 2004) {
                                    null
                                } else {
                                    menorIdade
                                }
                            }
                        }
                    }
                }

                1, 3, 5, 7, 8, 10, 12 -> { // meses com 31 dias
                    if (dia in 1..31) {
                        if (ano > 2004) {
                            return menorIdade
                        } else if (ano == 2004 && mes == 12) {
                            return menorIdade
                        }
                        return null
                    }

                }

                4, 6, 9, 11 -> { //meses com 30 dias
                    if (dia in 1..30) {
                        if (ano > 2004) {
                            return menorIdade
                        } else if (ano == 2004 && mes == 11) {
                            return menorIdade
                        }
                        return null
                    }
                }
            }
        }
    }
    return "errado"
}

fun validaDataNascimento(data: String?): String? {
    if (data != null) {
        if (data.length == 10) { //tamanho da string que recebemos
            if (data[2].code == 45 && data[5].code == 45) { // dia
                if (data[0].code in 48..51 && data[1].code in 48..57) { // mes
                    if (data[3].code in 48..49 && data[4].code in 48..57) {
                        if (verificaAno(data) != "errado") {
                            return verificaAno(data)
                        }
                    }
                }

            }
        }
    }
    return "Data invalida"
}

fun criaLegendaHorizontal(numColunas: Int): String {
    var linhaHorizontal = "A |"
    var letra = 'B'
    var count = 1
    while (count < numColunas) {
        if (count < numColunas - 1) { //verifica se é a a ultima coluna, se for entra no else
            linhaHorizontal += " $letra |"
            letra++
        } else {
            linhaHorizontal += " $letra"
        }
        count++
    }
    return linhaHorizontal
}

fun criaLegendaContadoresHorizontal(contadoresHorizontal: Array<Int?>): String {
    var resultado = ""
    for (numero in 0 until contadoresHorizontal.size) {
        if (numero == 0) { //quando é o primeiro espaço
            if (contadoresHorizontal[numero] == null) {
                resultado += "   "
            } else {
                resultado += "${contadoresHorizontal[numero]}  "
            }
        } else {//restante espaços
            if (numero < contadoresHorizontal.size - 1) {
                if (contadoresHorizontal[numero] == null) {
                    resultado += "    "
                } else {
                    resultado += " ${contadoresHorizontal[numero]}  "
                }
            } else if (contadoresHorizontal[numero] == null) { //verificação do ultimo espaço
                resultado += "   "
            } else if (contadoresHorizontal[numero] != null) { //verificação da ultimo espaço
                resultado += " ${contadoresHorizontal[numero]}"
            }
        }

    }
    return resultado
}

fun leContadoresDoFicheiro(numLines: Int, numColumns: Int, verticais: Boolean): Array<Int?> {
    val ficheiro = File("$numLines" + "x" + "$numColumns" + ".txt").readLines()
    if (verticais) { //lê verticais
        val resultadoTrue: Array<Int?> = Array(numColumns) { null }
        val partes = ficheiro[0].split(',') //separar a virgula
        for (posicao in 0 until partes.size) {//verificar posição a posição
            if (partes[posicao].toInt() == 0) {
                resultadoTrue[posicao] = null
            } else { //dar o valor que está nessa posição
                resultadoTrue[posicao] = partes[posicao].toInt()
            }
        }
        return resultadoTrue
    } else { //lê horizontais
        val resultadoFalse: Array<Int?> = Array(numLines) { null }
        val partes = ficheiro[1].split(',') //separar a virgula
        for (posicao in 0 until partes.size) {//verificar posição a posição
            if (partes[posicao].toInt() == 0) {
                resultadoFalse[posicao] = null
            } else { //dar o valor que está nessa posição
                resultadoFalse[posicao] = partes[posicao].toInt()
            }
        }
        return resultadoFalse
    }
}

fun leTerrenoDoFicheiro(numLines: Int, numColumns: Int): Array<Array<String?>> {
    val matriz: Array<Array<String?>> = Array(numLines) { Array(numColumns) { null } }
    val ficheiroterreno = File("$numLines" + "x" + "$numColumns" + ".txt").readLines()
    for (linha in 2 until ficheiroterreno.size) { //vai ler apartir da linha 3 do ficheiro do terreno, as coordenadas
        val partes = ficheiroterreno[linha].split(',') //separar a virgula
        matriz[partes[0].toInt()][partes[1].toInt()] = "A" //vai colocar o A nas coordenadas indicadas no ficheiro
    }
    return matriz
}

fun criaTerreno(terreno: Array<Array<String?>>, contadoresVerticais: Array<Int?>?, contadoresHorizontais: Array<Int?>?,
                mostraLegendaHorizontal: Boolean = true, mostraLegendaVertical: Boolean = true): String {
    var terrenoFinal = ""
    if (mostraLegendaHorizontal && contadoresVerticais == null) { //inicio do terreno
        terrenoFinal += "     | " + criaLegendaHorizontal(terreno[0].size) + "\n"
    } else if (mostraLegendaHorizontal && contadoresVerticais != null) {
        terrenoFinal += "       " + criaLegendaContadoresHorizontal(contadoresVerticais) + "\n     | " +
                criaLegendaHorizontal(terreno[0].size) + "\n"
    } else if (contadoresVerticais != null) {
        terrenoFinal += "       " + criaLegendaContadoresHorizontal(contadoresVerticais) + "\n"
    }
    for (linha in 0 until terreno.size) { //preenche o lado esquerdo do terreno
        when {
            !mostraLegendaVertical && contadoresHorizontais == null -> terrenoFinal += "     |" //Fica "vazio"
            mostraLegendaVertical && contadoresHorizontais == null -> { when { //mostra os numeros de linhas
                    linha < 9 -> terrenoFinal += "   ${linha.plus(1)} |"
                    else -> terrenoFinal += "  ${linha.plus(1)} |" //verifica a ultima linha
                }
            }

            !mostraLegendaVertical && contadoresHorizontais != null -> { when { //mostra apenas os contadores
                    contadoresHorizontais[linha] != null -> terrenoFinal += "${contadoresHorizontais[linha]}    |"
                    else -> terrenoFinal += "     |"//se os contadores naquela linha for null, fica "vazio"
                }
            }

            mostraLegendaVertical && contadoresHorizontais != null -> { //mostra os contadores e o numero da linha
                if (contadoresHorizontais[linha] != null) { when {
                        linha < 9 -> terrenoFinal += "${contadoresHorizontais[linha]}  ${linha.plus(1)} |"
                        else -> terrenoFinal += "${contadoresHorizontais[linha]} ${linha.plus(1)} |" //verifica a ultima linha
                    }
                } else { when { //se os contadores naquela linha for null, fica "vazio", apenas fica o numero da linha
                        linha < 9 -> terrenoFinal += "   ${linha.plus(1)} |"
                        else -> terrenoFinal += "  ${linha.plus(1)} |" //verifica a ultima linha
                    }
                }
            }
        }
        for (coluna in 0 until terreno[0].size) { when { //coloca os caracteres dentro do terreno
                coluna < terreno[0].size - 1 -> { when { //espaços normais
                        terreno[linha][coluna] == null -> terrenoFinal += "   |"
                        terreno[linha][coluna] == "A" -> terrenoFinal += " △ |"
                        terreno[linha][coluna] == "T" -> terrenoFinal += " T |"
                    }
                }

                else -> { when {
                    linha < terreno.size - 1 -> { when { //ultima coluna de uma linha
                        terreno[linha][coluna] == null -> terrenoFinal += "  \n"
                        terreno[linha][coluna] == "A" -> terrenoFinal += " △\n"
                        terreno[linha][coluna] == "T" -> terrenoFinal += " T\n"
                    }
                    }

                    else -> { when { //ultima linha e ultima coluna
                            terreno[linha][coluna] == null -> terrenoFinal += "  "
                            terreno[linha][coluna] == "A" -> terrenoFinal += " △"
                            terreno[linha][coluna] == "T" -> terrenoFinal += " T"
                        }
                    }
                }
                }
            }
        }
    }
    return terrenoFinal
}


fun processaCoordenadas(coordenadasStr: String?, numLines: Int, numColumns: Int): Pair<Int, Int>? {
    var verificaStr = 0
    var numeroCoordenada = ""
    var virgula = -1
    if (coordenadasStr != null && coordenadasStr.length >= 3) {  //verifica se as coordenadas são válidas
        while (verificaStr < coordenadasStr.length) {
            if (virgula == -1 && coordenadasStr[verificaStr] != ',') {
                //verifica se a virgula foi encontrada e se o caracter em questão é != da virgula
                if (coordenadasStr[verificaStr].code in 48..57) { //verifica se o caracter está entre 0..9
                    numeroCoordenada += (coordenadasStr[verificaStr]).toString() //guarda o caracter da posição(verificastr) das coordenadas
                } else {
                    verificaStr = coordenadasStr.length //iguala para sair do while
                }
            } else if (virgula == -1) { // verifica apenas se a virgula foi encontrada
                virgula = verificaStr + 1 // guarda a posição da virgula e aumenta 1 para ir para o caracter seguinte á virgula
            }
            verificaStr++
        }
        if (virgula != -1 && virgula != coordenadasStr.length && numeroCoordenada != "") {
            // verifica se tem virgula, se a virgula está dentro da coordenada e se depois da virgula não esá vazio
            if (numeroCoordenada.toInt() in 1..numLines && coordenadasStr[virgula].code in 65..65 + (numColumns - 1)) {
                //verifica se as coordendas estão validas(numeros,letras) e conforme o terreno
                return Pair((numeroCoordenada).toInt() - 1, coordenadasStr[virgula].code - 65)
            }
        }
    }
    return null
}

fun temArvoreAdjacente(terreno: Array<Array<String?>>, coords: Pair<Int, Int>): Boolean {
    return if (coords.first + 1 < terreno.size && terreno[coords.first + 1][coords.second] == "A") { //verifica em baixo
        true
    } else if (coords.first - 1 >= 0 && terreno[coords.first - 1][coords.second] == "A") { //verifica em cima
        true
    } else if (coords.second + 1 < terreno[0].size && terreno[coords.first][coords.second + 1] == "A") { //verifica á direita
        true
    } else coords.second - 1 >= 0 && terreno[coords.first][coords.second - 1] == "A" //verifica á esquerda
}

fun temTendaAdjacente(terreno: Array<Array<String?>>, coords: Pair<Int, Int>): Boolean {
    return if (coords.first + 1 < terreno.size && terreno[coords.first + 1][coords.second] == "T") { //verifica em baixo
        true
    } else if (coords.first - 1 >= 0 && terreno[coords.first - 1][coords.second] == "T") { //verifica em cima
        true
    } else if (coords.second + 1 < terreno[0].size && terreno[coords.first][coords.second + 1] == "T") {
        //verifica á direita
        true
    } else if ((coords.second - 1 >= 0 && coords.first - 1 >= 0) && terreno[coords.first - 1][coords.second - 1] == "T") {
        //verifica á esquerda e em cima
        true
    } else if ((coords.second + 1 < terreno[0].size && coords.first - 1 >= 0) && terreno[coords.first - 1][coords.second + 1] == "T") {
        //verifica á direita e em cima
        true
    } else if ((coords.first + 1 < terreno.size && coords.second - 1 >= 0) && terreno[coords.first + 1][coords.second - 1] == "T") {
        //verifica á esquerda e em baixo
        true
    } else if ((coords.second + 1 < terreno[0].size && coords.first + 1 < terreno.size) && terreno[coords.first + 1][coords.second + 1] == "T") {
        //verifica á direita e em baixo
        true
    } else coords.second - 1 >= 0 && terreno[coords.first][coords.second - 1] == "T" //verifica á esquerda
}

fun contaTendasColuna(terreno: Array<Array<String?>>, coluna: Int): Int {
    var countTendasColuna = 0
    if (coluna in 0 until terreno[0].size) {
        for (linha in 0 until terreno.size) {
            if (terreno[linha][coluna] == "T") {//verifica posição a posição, se tiver T
                countTendasColuna++ //aumenta a o nº de tendas na coluna
            }
        }
    }

    return countTendasColuna
}

fun contaTendasLinha(terreno: Array<Array<String?>>, linha: Int): Int {
    var countTendasLinha = 0
    if (linha in 0 until terreno.size) {
        for (coluna in 0 until terreno[0].size) {
            if (terreno[linha][coluna] == "T") {//verifica posição a posição, se tiver T
                countTendasLinha++//aumenta a o nº de tendas na linha
            }
        }
    }
    return countTendasLinha
}

fun colocaTenda(terreno: Array<Array<String?>>, coords: Pair<Int, Int>): Boolean {
    if (terreno[coords.first][coords.second] == null || terreno[coords.first][coords.second] == "T") {
        if (temArvoreAdjacente(terreno, coords)) {
            if (!temTendaAdjacente(terreno, coords)) {
                if (terreno[coords.first][coords.second] == "T") {
                    //para retirar a tenda quando voltamos a colocar as mesmas coodenadas
                    terreno[coords.first][coords.second] = null
                } else {
                    terreno[coords.first][coords.second] = "T" //coleca T no espaço das coordenadas indicadas
                }
                return true
            }
        }
    }
    return false
}

fun terminouJogo(terreno: Array<Array<String?>>, contadoresVerticais: Array<Int?>, contadoresHorizontais: Array<Int?>): Boolean {
    for (linha in 0 until terreno.size) {
        val contaTendasLinha = contaTendasLinha(terreno, linha)
        val tendasLinha = contadoresHorizontais[linha] ?: 0
        if (contaTendasLinha != tendasLinha) { //enquanto as não tiverem as tendas pedidas nas linhas, o jogo não acaba
            return false
        }
    }
    for (coluna in 0 until terreno[0].size) {
        val contaTendasColuna = contaTendasColuna(terreno, coluna)
        val tendasColuna = contadoresVerticais[coluna] ?: 0
        if (contaTendasColuna != tendasColuna) { //enquanto as não tiverem as tendas pedidas nas colunas, o jogo não acaba
            return false
        }
    }
    return true
}

fun main() {
    do {
        println(criaMenu())
        val datainvalida = "Data invalida"
        var linhas: Int
        var colunas: Int
        var coordenadas: String
        var coordenadasPair: Pair<Int, Int> = Pair(-1, -1)
        val querSair = "sair"
        val querJogarAux = readln()
        if (querJogarAux == querSair) return //sai do jogo
        val querJogar = querJogarAux.toIntOrNull() ?: -1
        if (querJogar == 1) { //inicia o jogo
            do {
                println("Quantas linhas?")
                val linhasAux = readln()
                if (linhasAux == querSair) return //sai do jogo
                linhas = linhasAux.toIntOrNull() ?: -1
                if (linhas <= 0) println("Resposta invalida")
            } while (linhas <= 0)
            do {
                println("Quantas colunas?")
                val colunasAux = readln()
                if (colunasAux == querSair) return //sai do jogo
                colunas = colunasAux.toIntOrNull() ?: -1
                if (colunas <= 0) println("Resposta invalida")
            } while (colunas <= 0)
            val terreno = leTerrenoDoFicheiro(linhas, colunas)
            if (!validaTamanhoMapa(linhas, colunas)) {
                println("Terreno invalido")
            } else {
                if (linhas == 10 && colunas == 10) { // se o terreno for 10x10 verifica a idade, se for menor volta ao inicio se for maior continua
                    if(auxiliarMain(querSair,terreno,linhas,colunas,datainvalida)== querSair){
                        return //sai do jogo
                    }else{
                        println("Parabens! Terminou o jogo!")
                    }
                } else { // se for outro terreno o programa mostra o terreno, se for válido
                    println("\n" + criaTerreno(terreno, leContadoresDoFicheiro(linhas, colunas, true),
                            leContadoresDoFicheiro(linhas, colunas, false)))
                    do {
                        do { // verificação das cordenadas
                            println("Coordenadas da tenda? (ex: 1,B)")
                            coordenadas = readln()
                            if (coordenadas == querSair) return //sai do jogoa
                            if (processaCoordenadas(coordenadas, linhas, colunas) == null) {
                                println("Coordenadas invalidas")
                            }
                        } while (processaCoordenadas(coordenadas, linhas, colunas) == null) //só sai quando forem coordenadas válidas
                        val verificaCoordenadas = processaCoordenadas(coordenadas, linhas, colunas)
                        //a função transforma as coordenadas no formato pedido
                        if (verificaCoordenadas != null) {
                            //Dá o valor das coordenas
                            coordenadasPair = verificaCoordenadas
                        }
                        if (!colocaTenda(terreno, coordenadasPair)) { //verifica se as cordenadas são as corretas segundo os ficheiros de cada terreno
                            println("Tenda nao pode ser colocada nestas coordenadas")
                        } else {
                            println("\n" + criaTerreno(terreno, leContadoresDoFicheiro(linhas, colunas, true),
                                    leContadoresDoFicheiro(linhas, colunas, false)))
                        }
                    } while (!terminouJogo(terreno, leContadoresDoFicheiro(linhas, colunas, true), leContadoresDoFicheiro(linhas, colunas, false)))
                    // só sai do while quando a tendas estão no espaço certo, logo o jogo está acabado
                    println("Parabens! Terminou o jogo!")
                }
            }
        } else if (querJogar != 0) {
            println("Opcao invalida")
        }
    } while (querJogar != 0) // se for 0 acaba o programa
}